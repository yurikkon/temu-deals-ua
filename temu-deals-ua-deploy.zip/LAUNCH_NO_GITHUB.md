# Temu Скидки UA - ЗАПУСК
# Всё через Telegram - статистика в реальном времени!

## СПОСОБ 1: Бесплатный PythonAnywhere (самый простой!)

1. Зайди на https://www.pythonanywhere.com/ (регистрация бесплатно)
2. Нажми "Bash" и выполни:
   ```
   git clone https://github.com/твой-username/temu-deals-ua.git
   cd temu-deals-ua
   pip install python-telegram-bot requests aiohttp
   python simple_bot.py &
   ```

## СПОСОБ 2: Render.com (тоже бесплатно)

1. Зайди на https://render.com и зарегистрируйся
2. Нажми "New" → "Web Service"
3. Подключи GitHub репозиторий
4. Настрой:
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `python simple_bot.py`
5. В Environment Variables добавь:
   - TELEGRAM_TOKEN: `7980953569:AAHwUSUwy2zaJuxAeLAcSmpoljhYJHCAtmk`
   - CHANNEL_ID: `@temu_skidki_ua`
   - TEMU_AFFILIATE_CODE: `ale040196`

## СПОСОБ 3: VPS/Сервер

```bash
# Установка
git clone https://github.com/твой-username/temu-deals-ua.git
cd temu-deals-ua
pip install -r requirements.txt

# Запуск в фоне
nohup python simple_bot.py > bot.log 2>&1 &

# Проверка
tail -f bot.log
```

## КОМАНДЫ Telegram-бота:

После запуска напиши боту @Temu_skidki_ua_bot:

- `/stats` - статистика в реальном времени
- `/post` - опубликовать скидку вручную
- `/promo` - запустить продвижение
- `/earn` - заработок
- `/help` - помощь

## ПАНЕЛЬ В РЕАЛЬНОМ ВРЕМЕНИ:

После запуска `web_dashboard.py` открой в браузере:
- На компьютере: http://localhost:8080
- С телефона: http://IP_адрес:8080

## АВТОПОСТИНГ:

Система автоматически публикует скидки:
- 09:00 - пост #1
- 12:00 - пост #2
- 15:00 - пост #3
- 18:00 - пост #4
- 21:00 - пост #5

**Никакого участия не требуется!**

## ПЕРЕМЕННЫЕ ОКРУЖЕНИЯ:

| Переменная | Значение |
|------------|----------|
| TELEGRAM_TOKEN | `7980953569:AAHwUSUwy2zaJuxAeLAcSmpoljhYJHCAtmk` |
| CHANNEL_ID | `@temu_skidki_ua` |
| TEMU_AFFILIATE_CODE | `ale040196` |
| ADMIN_CHAT_ID | Твой Telegram ID (опционально) |

## УЗНАТЬ СВОЙ TELEGRAM ID:

1. Напиши @userinfobot в Telegram
2. Он пришлёт твой ID (число)
3. Добавь его как ADMIN_CHAT_ID для получения уведомлений

---

**Готово! Канал работает автоматически 24/7! 🚀**
